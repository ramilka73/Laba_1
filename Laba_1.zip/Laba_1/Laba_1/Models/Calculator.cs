﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace Laba_1.Models
{
    public class Calculator
    {
        [Required (ErrorMessage = "Укажите первое значение")]
        public uint Operand_1 { get; set;}

        [Required(ErrorMessage = "Укажите второе значение")]
        [Range(0, 1000, ErrorMessage = "Недопустимый диапазон. Диапазон числа: 0 - 1000")]
        public double Operand_2 { get; set;}

        public double Result { get; set;}
        public char Sign { get; set;}
    }
}